package persons.tasks.generator;

import com.google.common.base.Objects;
import java.util.Arrays;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import persons.tasks.generator.Auxiliary;
import persons.tasks.taskDSL.Action;
import persons.tasks.taskDSL.Balance;
import persons.tasks.taskDSL.Duration;
import persons.tasks.taskDSL.ExpressionAddition;
import persons.tasks.taskDSL.ExpressionBalance;
import persons.tasks.taskDSL.ExpressionBracket;
import persons.tasks.taskDSL.ExpressionConstantInt;
import persons.tasks.taskDSL.ExpressionDivision;
import persons.tasks.taskDSL.ExpressionMaximum;
import persons.tasks.taskDSL.ExpressionMinimum;
import persons.tasks.taskDSL.ExpressionMinus;
import persons.tasks.taskDSL.ExpressionModulo;
import persons.tasks.taskDSL.ExpressionMultiply;
import persons.tasks.taskDSL.ExpressionPlus;
import persons.tasks.taskDSL.ExpressionPower;
import persons.tasks.taskDSL.ExpressionSubstraction;
import persons.tasks.taskDSL.LunchAction;
import persons.tasks.taskDSL.MeetingAction;
import persons.tasks.taskDSL.PaperAction;
import persons.tasks.taskDSL.PaymentAction;
import persons.tasks.taskDSL.Person;
import persons.tasks.taskDSL.Planning;
import persons.tasks.taskDSL.Task;
import persons.tasks.taskDSL.TimeUnit;

@SuppressWarnings("all")
public class TextGenerator {
  public static CharSequence toText(final Planning root) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Info of the planning ");
    String _name = root.getName();
    _builder.append(_name);
    _builder.newLineIfNotEmpty();
    _builder.append("All Persons:");
    _builder.append("\n");
    _builder.newLineIfNotEmpty();
    {
      EList<Person> _persons = root.getPersons();
      for(final Person p : _persons) {
        _builder.append("\t");
        String _name_1 = p.getName();
        _builder.append(_name_1);
        _builder.append("\n");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("All actions of tasks:");
    _builder.newLine();
    {
      EList<Task> _tasks = root.getTasks();
      boolean _hasElements = false;
      for(final Task t : _tasks) {
        if (!_hasElements) {
          _hasElements = true;
          _builder.append("======  \n");
        } else {
          _builder.appendImmediate("  &  ", "");
        }
        CharSequence _action2Text = TextGenerator.action2Text(t.getAction());
        _builder.append(_action2Text);
        CharSequence _infoAction = TextGenerator.infoAction(t);
        _builder.append(_infoAction);
        _builder.newLineIfNotEmpty();
      }
      if (_hasElements) {
        _builder.append("=====");
      }
    }
    _builder.append("     ");
    _builder.newLine();
    _builder.append("     ");
    _builder.append("Other way of listing all tasks:");
    _builder.newLine();
    {
      List<Action> _actions = Auxiliary.getActions(root);
      boolean _hasElements_1 = false;
      for(final Action a : _actions) {
        if (!_hasElements_1) {
          _hasElements_1 = true;
        } else {
          _builder.appendImmediate(",", "     ");
        }
        _builder.append("     ");
        CharSequence _action2Text_1 = TextGenerator.action2Text(a);
        _builder.append(_action2Text_1, "     ");
        _builder.newLineIfNotEmpty();
        _builder.append("     ");
      }
    }
    return _builder;
  }
  
  protected static CharSequence _action2Text(final LunchAction action) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Lunch at location");
    String _location = action.getLocation();
    _builder.append(_location);
    return _builder;
  }
  
  protected static CharSequence _action2Text(final MeetingAction action) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Meeting with topic");
    String _topic = action.getTopic();
    _builder.append(_topic);
    return _builder;
  }
  
  protected static CharSequence _action2Text(final PaperAction action) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Paper for journal");
    String _report = action.getReport();
    _builder.append(_report);
    return _builder;
  }
  
  protected static CharSequence _action2Text(final PaymentAction action) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  public static CharSequence infoAction(final Task t) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Duration _duration = t.getDuration();
      boolean _notEquals = (!Objects.equal(_duration, null));
      if (_notEquals) {
        _builder.append(" with duration: ");
        int _dl = t.getDuration().getDl();
        _builder.append(_dl);
        _builder.append(" ");
        CharSequence _text = TextGenerator.toText(t.getDuration().getUnit());
        _builder.append(_text);
      }
    }
    return _builder;
  }
  
  public static CharSequence toText(final TimeUnit u) {
    if (u != null) {
      switch (u) {
        case MINUTE:
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("m");
          return _builder;
        case HOUR:
          StringConcatenation _builder_1 = new StringConcatenation();
          _builder_1.append("h");
          return _builder_1;
        case DAY:
          StringConcatenation _builder_2 = new StringConcatenation();
          _builder_2.append("d");
          return _builder_2;
        case WEEK:
          StringConcatenation _builder_3 = new StringConcatenation();
          _builder_3.append("w");
          return _builder_3;
        default:
          break;
      }
    }
    return null;
  }
  
  protected static CharSequence _generateExpression(final ExpressionAddition expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionSubstraction expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionMultiply expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionDivision expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionMaximum expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionMinimum expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionModulo expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionPower expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionMinus expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionPlus expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionBracket expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp");
  }
  
  protected static CharSequence _generateExpression(final ExpressionConstantInt expr) {
    StringConcatenation _builder = new StringConcatenation();
    int _value = expr.getValue();
    _builder.append(_value);
    return _builder;
  }
  
  protected static CharSequence _generateExpression(final ExpressionBalance expr) {
    StringConcatenation _builder = new StringConcatenation();
    Balance _value = expr.getValue();
    _builder.append(_value);
    return _builder;
  }
  
  protected static CharSequence _generateExpression(final /* ExpressionBinOp */Object expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method genBinOp(BinaryBooleanOperator) from the type TextGenerator refers to the missing type BinaryBooleanOperator"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nleft cannot be resolved"
      + "\nbop cannot be resolved"
      + "\nright cannot be resolved");
  }
  
  protected static CharSequence _genBinOp(final /* BinaryBooleanOperator */Object op) {
    throw new Error("Unresolved compilation problems:"
      + "\nBinaryBooleanOperator cannot be resolved to a type."
      + "\nBinaryBooleanOperator cannot be resolved to a type."
      + "\nAND cannot be resolved"
      + "\nOR cannot be resolved");
  }
  
  protected static CharSequence _generateExpression(final /* ExpressionCompOp */Object expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nThe method genCompOp(CompareOperator) from the type TextGenerator refers to the missing type CompareOperator"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nleft cannot be resolved"
      + "\nop cannot be resolved"
      + "\nright cannot be resolved");
  }
  
  public static CharSequence genCompOp(final /* CompareOperator */Object op) {
    throw new Error("Unresolved compilation problems:"
      + "\nCompareOperator cannot be resolved to a type."
      + "\nCompareOperator cannot be resolved to a type."
      + "\nCompareOperator cannot be resolved to a type."
      + "\nCompareOperator cannot be resolved to a type."
      + "\nCompareOperator cannot be resolved to a type."
      + "\nCompareOperator cannot be resolved to a type."
      + "\nEQ cannot be resolved"
      + "\nNEQ cannot be resolved"
      + "\nGEQ cannot be resolved"
      + "\nG cannot be resolved"
      + "\nLEQ cannot be resolved"
      + "\nL cannot be resolved");
  }
  
  protected static CharSequence _generateExpression(final /* BooleanExpressionBracket */Object expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nsub cannot be resolved");
  }
  
  protected static CharSequence _generateExpression(final /* NotExpression */Object expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method generateExpression(ExpressionBinOp) from the type TextGenerator refers to the missing type ExpressionBinOp"
      + "\nsub cannot be resolved");
  }
  
  protected static CharSequence _generateExpression(final /* BooleanExpressionConstant */Object expr) {
    throw new Error("Unresolved compilation problems:"
      + "\nvalue cannot be resolved");
  }
  
  public static CharSequence action2Text(final Action action) {
    if (action instanceof LunchAction) {
      return _action2Text((LunchAction)action);
    } else if (action instanceof MeetingAction) {
      return _action2Text((MeetingAction)action);
    } else if (action instanceof PaperAction) {
      return _action2Text((PaperAction)action);
    } else if (action instanceof PaymentAction) {
      return _action2Text((PaymentAction)action);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(action).toString());
    }
  }
  
  public static CharSequence generateExpression(final ExpressionBinOp expr) {
    if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else if (expr != null) {
      return _generateExpression(expr);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(expr).toString());
    }
  }
  
  public static CharSequence genBinOp(final BinaryBooleanOperator op) {
    if (op != null) {
      return _genBinOp(op); else {
        throw new IllegalArgumentException("Unhandled parameter types: " +
          Arrays.<Object>asList(op).toString());
      }
    }
  }
  